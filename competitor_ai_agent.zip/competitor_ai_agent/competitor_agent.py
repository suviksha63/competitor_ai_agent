from groq import Groq

client = Groq(api_key="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")

def generate_report(location):
    
    competitor_data = [
        {"name": "Zudio", "rating": 4.2, "peak_hours": "5 PM - 9 PM"},
        {"name": "Westside", "rating": 4.4, "peak_hours": "4 PM - 8 PM"},
        {"name": "H&M", "rating": 4.3, "peak_hours": "6 PM - 10 PM"}
    ]

    prompt = f"""
You are a retail market analyst.

Location: {location}

Competitor Data:
{competitor_data}

Generate a business competitor analysis report including:
1. Top competitors
2. Peak footfall analysis
3. Strategic recommendations
4. Marketing suggestions
"""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content


if __name__ == "__main__":
    location = input("Enter location: ")
    report = generate_report(location)
    print("\n===== BUSINESS REPORT =====\n")
    print(report)